import React, { useEffect, useState } from 'react';
import { supabase } from './supabase';

export default function App() {
  const [items, setItems] = useState([]);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [description, setDescription] = useState('');
  const [city, setCity] = useState('');
  const [message, setMessage] = useState('Welcome! Help good food reach people who need it.');
  const configured = Boolean(supabase);

  async function loadItems() {
    if (!supabase) return;
    const { data, error } = await supabase.from('food_listings').select('*').eq('status', 'available').order('created_at', { ascending: false });
    if (error) setMessage(error.message); else setItems(data || []);
  }
  useEffect(() => { loadItems(); }, []);

  async function signUp() {
    if (!supabase) return setMessage('Connect your Supabase project first.');
    const { error } = await supabase.auth.signUp({ email, password });
    setMessage(error ? error.message : 'Check your email to confirm your account.');
  }
  async function signIn() {
    if (!supabase) return setMessage('Connect your Supabase project first.');
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setMessage(error ? error.message : 'You are signed in.');
  }
  async function addListing(e) {
    e.preventDefault();
    if (!supabase) return setMessage('Connect your Supabase project first.');
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return setMessage('Please sign in before posting food.');
    const { error } = await supabase.from('food_listings').insert({ donor_id: user.id, title: name, description, city });
    if (error) setMessage(error.message);
    else { setMessage('Food listing added. Thank you!'); setName(''); setDescription(''); setCity(''); loadItems(); }
  }

  return <main>
    <header><div className="brand">🥬 Food Rescue</div><span>Save food. Share hope.</span></header>
    <section className="hero"><p className="eyebrow">LESS WASTE • MORE MEALS</p><h1>Good food deserves<br/>a second chance.</h1><p>Connect food donors with charities and volunteers to help reduce food waste.</p><a href="#donate" className="cta">Donate surplus food</a></section>
    <p className="notice">{message}</p>
    {!configured && <p className="setup">Setup needed: add your Supabase URL and anon key as Netlify environment variables.</p>}
    <section className="panel"><h2>Join Food Rescue</h2><p>Create an account or sign in to help.</p><input aria-label="Email" placeholder="Email address" value={email} onChange={e=>setEmail(e.target.value)}/><input aria-label="Password" type="password" placeholder="Password" value={password} onChange={e=>setPassword(e.target.value)}/><div className="actions"><button onClick={signUp}>Create account</button><button className="secondary" onClick={signIn}>Sign in</button></div></section>
    <section id="donate" className="panel"><h2>Share available food</h2><form onSubmit={addListing}><input required placeholder="Food title (e.g. Fresh bread)" value={name} onChange={e=>setName(e.target.value)}/><textarea placeholder="Describe the food and quantity" value={description} onChange={e=>setDescription(e.target.value)}/><input placeholder="City / area" value={city} onChange={e=>setCity(e.target.value)}/><button type="submit">Post food</button></form><small>Only list food that has been safely stored and is suitable for donation. Follow local food-safety rules.</small></section>
    <section className="list"><h2>Available food</h2>{items.length ? items.map(x=><article key={x.id}><h3>{x.title}</h3><p>{x.description}</p><small>{x.city}</small></article>) : <p>No listings yet. Be the first to help.</p>}</section>
    <footer>Food Rescue • A community-powered food sharing project</footer>
  </main>;
}