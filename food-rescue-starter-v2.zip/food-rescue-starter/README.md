# Food Rescue starter

A starter web app for connecting food donors with people and organizations that can redistribute surplus food.

## What is included
- React + Vite front end
- Supabase email sign-up and sign-in
- Basic food listing form and available-listings feed
- SQL schema with basic row-level security

## Important
This is an early prototype, not a production-ready food distribution service. Before real-world use, add organization verification, pickup/reservation workflows, moderation, privacy review, and robust food-safety procedures. Do not list food unless it has been safely handled and is legally suitable for donation.

## Supabase setup
1. Create a Supabase project.
2. Open SQL Editor, create a new query, paste `supabase/schema.sql`, and run it.
3. In Project Settings > API, copy the Project URL and anon/public key.
4. Add these environment variables to your hosting provider:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
Never put a `service_role` key in frontend code.

## Deploy
Deploy this Vite project using a host that supports Vite builds. Build command: `npm run build`. Publish directory: `dist`.
